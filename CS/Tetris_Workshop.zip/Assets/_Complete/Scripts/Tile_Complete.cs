﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile_Complete : MonoBehaviour
{
    private GameObject block;

    public void Start()
    {
        block = this.gameObject;
    }

    public bool CanMoveDown(bool[,] board)
    {
        Vector3 currPosition = block.GetComponent<Transform>().position;
        //Debug.Log(TetrisBlock.name);
        //Debug.Log(currPosition);
        int nextX = (int)currPosition.x;
        int nextY = (int)currPosition.y - 1;
        if (nextY < 0)
        {
            return false;
        }
        // Next location on tetris board is available and I move.
        if (nextY > 17 || !board[nextX, nextY]) {
            return true;
        }
        return false;
    }

    public void MoveDown(bool[,] board) {
        block.GetComponent<Transform>().position -= new Vector3(0, 1, 0);
        Vector3 currPosition = block.GetComponent<Transform>().position;

        //Debug.Log(TetrisBlock.name);
        //Debug.Log(currPosition);
        int x = (int)currPosition.x;
        int y = (int)currPosition.y;

        if (y < 17)
        {
            board[x, y + 1] = false;
            board[x, y] = true;
        }
        else if (y == 17)
        {
            board[x, y] = true;
        }
    }

    public void MoveUp(bool[,] board) {
        Vector3 currPosition = block.GetComponent<Transform>().position;

        //Debug.Log(TetrisBlock.name);
        //Debug.Log(currPosition);
        int x = (int)currPosition.x;
        int y = (int)currPosition.y;

        if (y < 17)
        {
            board[x, y + 1] = true;
            board[x, y] = false;
        }
        else if (y == 17)
        {
            board[x, y] = false;
        }

        block.GetComponent<Transform>().position += new Vector3(0, 1, 0);
    }

    public bool CanMoveHorizontal(bool[,] board, int direction) {
        
        Vector3 currPosition = block.GetComponent<Transform>().position;
        int nextX = (int)currPosition.x + direction;
        int nextY = (int)currPosition.y;

        if (nextY < 0 || nextY > 17 || nextX < 0 || nextX > 9)
        {
            return false;
        }

        // Next location on tetris board is available and I can move.
        // Debug.Log(board[nextX, nextY]);
        if (!board[nextX, nextY])
        {
            return true;
        }

        return false;
    }

    public void MoveHorizontal(int direction, bool[,] board) {
        block.GetComponent<Transform>().position += new Vector3(direction, 0, 0);

        Vector3 currPosition = block.GetComponent<Transform>().position;

        //Debug.Log(TetrisBlock.name);
        //Debug.Log(currPosition);
        int x = (int)currPosition.x;
        int y = (int)currPosition.y;

        board[x - direction, y] = false;
        board[x, y] = true;
    }

    public Vector3 GetPosition() {
        return block.GetComponent<Transform>().position;        
    }
}
