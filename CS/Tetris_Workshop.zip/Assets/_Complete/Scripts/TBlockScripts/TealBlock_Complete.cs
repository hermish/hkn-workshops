﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TealBlock_Complete : TBlock_Complete
{
    protected override void Start()
    {
        base.Start();

        bottomTiles = new List<Tile_Complete>(blockTiles);
        upperTiles = bottomTiles;
        rightTiles.Add(blockTiles[2]);
        leftTiles.Add(blockTiles[3]);

        pivotTile = blockTiles[0];

        orientation = 0;

        tileLayout = new int[5, 5] {
            {0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0},
            {0, 1, 1, 1, 1},
            {0, 0, 0, 0, 0}, 
            {0, 0, 0, 0, 0}
        };
    }

    public override bool CanRotate(bool[,] board) {
        try
        {
            Debug.Log("Teal CanRotate");
            Vector3 location = pivotTile.GetPosition();
            int locX = (int)location.x;
            int locY = (int)location.y;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (tileLayout[i, j] == 0 && board[locX + (j - 2), locY + 2 - i])
                    {
                        Debug.Log("Cannot rotate");
                        return false;
                    }
                }
            }
            Debug.Log("Can Rotate");
            return true;
        }
        catch (System.IndexOutOfRangeException e)
        {
            Debug.Log("Index out of bounds error");
            return false;
        }
    }

    public override void TryRotation(bool[,] board)
    {
        base.TryRotation(board);

        Vector3 pivotLocation = pivotTile.GetPosition();
        int pivotX = (int)pivotLocation.x;
        int pivotY = (int)pivotLocation.y;

        // Base Rotation takes care of all tiles except far tile which is done manually

        Tile_Complete farTile = blockTiles[2];
        Vector3 tilePosition = farTile.GetPosition();
        int tileX = (int)tilePosition.x;
        int tileY = (int)tilePosition.y;

        // Four cases for the far tile. 

        //FarRight -> FarBottom
        if (tileX - pivotX == 2 && tileY - pivotY == 0)
        {
            farTile.MoveDown(board);
            farTile.MoveDown(board);
            farTile.MoveHorizontal(-1, board);
            farTile.MoveHorizontal(-1, board);
        }
        //FarBottom -> FarLeft
        if (tileX - pivotX == 0 && tileY - pivotY == -2)
        {
            farTile.MoveHorizontal(-1, board);
            farTile.MoveHorizontal(-1, board);
            farTile.MoveUp(board);
            farTile.MoveUp(board);
        }
        //FarLeft -> FarUpper
        if (tileX - pivotX == -2 && tileY - pivotY == 0)
        {
            farTile.MoveUp(board);
            farTile.MoveUp(board);
            farTile.MoveHorizontal(1, board);
            farTile.MoveHorizontal(1, board);
        }
        //FarUpper -> FarRight
        if (tileX - pivotX == 0 && tileY - pivotY == 2)
        {
            farTile.MoveHorizontal(1, board);
            farTile.MoveHorizontal(1, board);
            farTile.MoveDown(board);
            farTile.MoveDown(board);
        }

        switch (orientation)
        {
            case 0:
                tileLayout = new int[5, 5] {
            {0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0}
        };
                orientation = 1;
                break;
            case 1:
                tileLayout = new int[5, 5] {
            {0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0},
            {1, 1, 1, 1, 0},
            {0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0}
        };
                orientation = 2;
                break;
            case 2:
                tileLayout = new int[5, 5] {
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 1, 0, 0},
            {0, 0, 0, 0, 0}
        };
                orientation = 3;
                break;
            case 3:
                tileLayout = new int[5, 5] {
            {0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0},
            {0, 1, 1, 1, 1},
            {0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0}
        };
                orientation = 0;
                break;
        }
    }
}
