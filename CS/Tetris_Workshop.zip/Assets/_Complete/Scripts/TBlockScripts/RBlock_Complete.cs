﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RBlock_Complete : TBlock_Complete
{
    protected override void Start()
    {
        base.Start();

        bottomTiles.Add(blockTiles[0]);
        bottomTiles.Add(blockTiles[3]);

        upperTiles.Add(blockTiles[1]);
        upperTiles.Add(blockTiles[2]);

        rightTiles.Add(blockTiles[2]);
        rightTiles.Add(blockTiles[3]);

        leftTiles.Add(blockTiles[0]);
        leftTiles.Add(blockTiles[1]);
    }

    public override bool CanRotate(bool[,] board)
    {
        return false;
    }

    public override void TryRotation(bool[,] board)
    {
        return;
    }
}
