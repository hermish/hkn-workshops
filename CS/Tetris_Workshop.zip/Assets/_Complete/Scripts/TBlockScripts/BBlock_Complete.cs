﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BBlock_Complete : TBlock_Complete
{
    protected override void Start()
    {
        base.Start();

        bottomTiles.Add(blockTiles[2]);
        bottomTiles.Add(blockTiles[3]);

        upperTiles.Add(blockTiles[1]);
        upperTiles.Add(blockTiles[3]);

        rightTiles.Add(blockTiles[0]);
        rightTiles.Add(blockTiles[1]);
        rightTiles.Add(blockTiles[3]);

        leftTiles.Add(blockTiles[0]);
        leftTiles.Add(blockTiles[1]);
        leftTiles.Add(blockTiles[2]);

        pivotTile = blockTiles[0];

        tileLayout = new int[3, 3] {
            {0, 1, 0},
            {0, 1, 0},
            {0, 1, 1}
        };
    }

    public override void TryRotation(bool[,] board)
    {
        base.TryRotation(board);
        switch (orientation)
        {
            case 0:
                tileLayout = new int[3, 3] {
            {0, 0, 0},
            {1, 1, 1},
            {1, 0, 0}
        };
                orientation = 1;
                break;
            case 1:
                tileLayout = new int[3, 3] {
            {1, 1, 0},
            {0, 1, 0},
            {0, 1, 0}
        };
                orientation = 2;
                break;
            case 2:
                tileLayout = new int[3, 3] {
            {0, 0, 1},
            {1, 1, 1},
            {0, 0, 0}
        };
                orientation = 3;
                break;
            case 3:
                tileLayout = new int[3, 3] {
            {0, 1, 0},
            {0, 1, 0},
            {0, 1, 1}
        };
                orientation = 0;
                break;
        }
    }
}
