﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager_Complete : MonoBehaviour
{
    private int rows = 18;
    private int cols = 10;

    public bool[,] board;
    public GameObject backgroundTile;

    public List<GameObject> TetrisBlocks;

    private bool spawnReady;
    private bool movingAlready;
    private float spawnTimer = 1f;
    // private GameObject currentBlock;

    private TBlock_Complete currentBlock;

    private Transform tileHolder;

    void Start()
    {
        board = new bool[cols, rows];
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                board[i, j] = false;
            }
        }
        SetUpBoard();
        spawnReady = true;
        tileHolder = new GameObject("TileHolder").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnReady)
        {
            CheckCompleteRow();
            GameObject tileBlock = SpawnBlock();
            tileBlock.GetComponent<Transform>().parent = tileHolder;
            currentBlock = tileBlock.GetComponent<TBlock_Complete>();
            spawnReady = false;
        }
        else
        {
            StartCoroutine(MoveBlockDown());
        }

        // Move block horizontally according to player controls
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            TryMoveHorizontal(currentBlock, 1);
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            TryMoveHorizontal(currentBlock, -1);
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            TryMoveDown(currentBlock);
        }

        // Rotate block according to player controls
        if (Input.GetKeyDown(KeyCode.UpArrow)) {
            TryRotate(currentBlock);
        }

    }

    public void SetUpBoard()
    {
        Transform boardHolder = new GameObject("Board").GetComponent<Transform>();
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                GameObject background = Instantiate(backgroundTile, new Vector3(i, j, 0), Quaternion.identity);
                background.GetComponent<Transform>().parent = boardHolder;
            }
        }
    }

    public GameObject SpawnBlock()
    {
        GameObject TetrisBlock = TetrisBlocks[UnityEngine.Random.Range(0, TetrisBlocks.Count)];
        return Instantiate(TetrisBlock, new Vector3(5, 18, 0), Quaternion.identity);
    }

    IEnumerator MoveBlockDown()
    {
        while (!movingAlready)
        {
            movingAlready = true;
            yield return new WaitForSeconds(spawnTimer);
            TryMoveDown(currentBlock);
            movingAlready = false;
            // DebugBoard();
        }
    }

    void CheckCompleteRow()
    {
        for (int i = 0; i < rows; i++)
        {
            
            bool rowComplete = true;
            // Debug.Log("Check row: " + i.ToString());

            // For a single row, the maximum number of times we would have the 
            // "same" row contain a complete row is 4
            for (int iter = 0; iter < 4; iter++)
            {
                if (!rowComplete)
                {
                    break;
                }

                for (int j = 0; j < cols; j++)
                {
                    if (!board[j, i])
                    {
                        rowComplete = false;
                        break;
                    }
                }

                if (rowComplete)
                {
                    // Debug.Log("row:" + i.ToString() + " iter: " + iter.ToString());
                    for (int j = 0; j < cols; j++)
                    {
                        board[j, i] = false;
                    }
                    Tile_Complete[] tilesArray = tileHolder.GetComponentsInChildren<Tile_Complete>();
                    // Debug.Log(tilesArray.Length);
                    List<Tile_Complete> tiles = sortByY(tilesArray);
                    // Debug.Log(tiles.Count);

                    for (int k = 0; k < tiles.Count; k++)
                    {
                        int yIndex = (int) tiles[k].GetPosition().y;
                        // Debug.Log("yindex: " + yIndex.ToString() + " k: " + k.ToString());
                        if (yIndex == i)
                        {
                            Destroy(tiles[k].gameObject);
                        } else if (yIndex > i)
                        {
                            tiles[k].MoveDown(board);
                        }
                    }
                }
            }
        }
    }

    void TryMoveDown(TBlock_Complete TetrisBlock)
    {

        //if (TetrisBlock == null) {
        //    return;
        //}

        if (TetrisBlock.CanMoveDown(board))
        {
            TetrisBlock.MoveDown(board);
        }
        else
        {
            foreach (Tile_Complete tile in TetrisBlock.blockTiles)
            {
                if (tile.GetPosition().y > 17)
                {
                    Debug.Log("Game Over");
                    return;
                }
            }
            spawnReady = true;
            return;
        }
        Debug.Log("Block Moved Down");
    }

    void TryMoveHorizontal(TBlock_Complete TetrisBlock, int direction) {
        if (TetrisBlock.CanMoveHorizontal(board, direction)) {
            TetrisBlock.MoveHorizontal(board, direction);
            Debug.Log("Block Moved Horizontally");
        }
    }

    void TryRotate(TBlock_Complete TetrisBlock) {
        if (TetrisBlock.CanRotate(board)) {
            TetrisBlock.TryRotation(board);
            Debug.Log("Block rotated");
        }
    }

    void DebugBoard() {
        string rowString = "";
        for (int i = 17; i >= 0; i--) {
            for (int j = 0; j < 10; j++) {
                if (board[j, i])
                    rowString += 1.ToString() + " ";
                else
                    rowString += 0.ToString() + " ";
            }
            rowString += "\n";
        }
        Debug.Log(rowString);
    }

    // Return the blocktiles sorted by y index. Bottom tile (smallest y) in first index
    // Same as function from TBlock_Complete except for tileY length
    public List<Tile_Complete> sortByY(Tile_Complete[] tiles)
    {
        List<Tile_Complete> sortedTiles = new List<Tile_Complete>();
        int[] tilesY = new int[tiles.Length];

        for (int i = 0; i < tiles.Length; i++)
        {
            tilesY[i] = (int)(tiles[i].GetPosition().y);
        }
        Array.Sort(tilesY);

        for (int i = 0; i < tiles.Length; i++)
        {
            for (int j = 0; j < tiles.Length; j++)
            {
                if ((int)tiles[j].GetPosition().y == tilesY[i] && !sortedTiles.Contains(tiles[j]))
                {
                    sortedTiles.Add(tiles[j]);
                    break;
                }
            }
        }
        return sortedTiles;
    }
}
