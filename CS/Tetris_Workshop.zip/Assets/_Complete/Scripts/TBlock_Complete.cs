﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class TBlock_Complete : MonoBehaviour
{
    public Tile_Complete[] blockTiles;

    protected List<Tile_Complete> bottomTiles;
    protected List<Tile_Complete> upperTiles;
    protected List<Tile_Complete> leftTiles;
    protected List<Tile_Complete> rightTiles;

    protected Tile_Complete pivotTile;

    protected int orientation;

    protected int[,] tileLayout;

    protected virtual void Start()
    {
        // TODO: Need to remove the first item (parent)
        // Resolved: Parent item will not have Tile script attached. Only TBlock
        blockTiles = GetComponentsInChildren<Tile_Complete>();
        bottomTiles = new List<Tile_Complete>();
        upperTiles = new List<Tile_Complete>();
        leftTiles = new List<Tile_Complete>();
        rightTiles = new List<Tile_Complete>();
    }

    public void MoveHorizontal(bool[,] board, int direction) {
        if (CanMoveHorizontal(board, direction)) {
            List<Tile_Complete> sortedBlocksX = sortByX(blockTiles);
            if (direction == 1)
            {
                for (int i = 3; i >= 0; i--)
                {
                    sortedBlocksX[i].MoveHorizontal(direction, board);
                }
            } else if (direction == -1) {
                foreach (Tile_Complete tile in sortedBlocksX) {
                    tile.MoveHorizontal(direction, board);
                }
            }
        }
    }

    // Return the blocktiles sorted by y index. Left tile (smallest x) in first index
    public List<Tile_Complete> sortByX(Tile_Complete[] tiles) {
        List<Tile_Complete> sortedTiles = new List<Tile_Complete>();
        int[] tilesX = new int[4];

        for (int i = 0; i < 4; i++)
        {
            tilesX[i] = (int)(tiles[i].GetPosition().x);
        }
        Array.Sort(tilesX);

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                if ((int)tiles[j].GetPosition().x == tilesX[i] && !sortedTiles.Contains(tiles[j]))
                {
                    sortedTiles.Add(tiles[j]);
                    break;
                }
            }
        }

        return sortedTiles;
    }

    public void MoveDown(bool[,] board) {
        // gameObject.GetComponent<Transform>().position -= new Vector3(0, 1, 0);
        // Need to move bottom tiles first
        List<Tile_Complete> sortedBlocksY = sortByY(blockTiles);
        foreach (Tile_Complete tile in sortedBlocksY)
        {
            tile.MoveDown(board);
        }
    }

    // Return the blocktiles sorted by y index. Bottom tile (smallest y) in first index
    public List<Tile_Complete> sortByY(Tile_Complete[] tiles) {
        List<Tile_Complete> sortedTiles = new List<Tile_Complete>();
        int[] tilesY = new int[4];

        for (int i = 0; i < 4; i++) {
            tilesY[i] = (int) (tiles[i].GetPosition().y);
        }
        Array.Sort(tilesY);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if ((int) tiles[j].GetPosition().y == tilesY[i] && !sortedTiles.Contains(tiles[j])) {
                    sortedTiles.Add(tiles[j]);
                    break;
                }
            }
        }

        return sortedTiles;
    }

    public bool CanMoveHorizontal(bool[,] board, int direction)
    {
        bool canMove = true;
        if (direction == 1)
        {
            foreach (Tile_Complete tile in rightTiles)
            {
                canMove = canMove && tile.CanMoveHorizontal(board, direction);
            }
        } else if (direction == -1) {
            foreach (Tile_Complete tile in leftTiles)
            {
                canMove = canMove && tile.CanMoveHorizontal(board, direction);
            }
        }

        return canMove;
    }

    public bool CanMoveDown(bool[,] board)
    {
        bool canMove = true;

        if(bottomTiles == null) {
            Debug.Log("BottomTiles Null");
            return false;
        }

        foreach (Tile_Complete tile in bottomTiles)
        {
            canMove = canMove && tile.CanMoveDown(board);
        }

        return canMove;
    }

    public virtual bool CanRotate(bool[,] board)
    {
        try
        {
            Vector3 location = pivotTile.GetPosition();
            int locX = (int)location.x;
            int locY = (int)location.y;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tileLayout[i, j] == 0 && board[locX + (j - 1), locY + 1 - i])
                    {
                        Debug.Log("Cannot rotate");
                        return false;
                    }
                }
            }
            Debug.Log("Can Rotate");
            return true;
        }
        catch (System.IndexOutOfRangeException e)
        {
            Debug.Log("Index out of bounds error");
            return false;
        }
    }

    public virtual void TryRotation(bool[,] board)
    {
        Vector3 pivotLocation = pivotTile.GetPosition();
        int pivotX = (int)pivotLocation.x;
        int pivotY = (int)pivotLocation.y;

        for (int i = 0; i < 4; i++)
        {
            Tile_Complete tile = blockTiles[i];
            Vector3 tilePosition = tile.GetPosition();
            int tileX = (int)tilePosition.x;
            int tileY = (int)tilePosition.y;

            // Eight cases for the various tiles. 

            // Right -> Bottom
            if (tileX - pivotX == 1 && tileY - pivotY == 0)
            {
                tile.MoveDown(board);
                tile.MoveHorizontal(-1, board);
            }
            // Bottom -> Left
            if (tileX - pivotX == 0 && tileY - pivotY == -1)
            {
                tile.MoveHorizontal(-1, board);
                tile.MoveUp(board);
            }
            // Left -> Upper
            if (tileX - pivotX == -1 && tileY - pivotY == 0)
            {
                tile.MoveHorizontal(1, board);
                tile.MoveUp(board);
            }
            // Upper -> Right
            if (tileX - pivotX == 0 && tileY - pivotY == 1)
            {
                tile.MoveHorizontal(1, board);
                tile.MoveDown(board);
            }
            //UpperRight -> LowerRight
            if (tileX - pivotX == 1 && tileY - pivotY == 1)
            {
                tile.MoveDown(board);
                tile.MoveDown(board);
            }
            //LowerRight -> LowerLeft
            if (tileX - pivotX == 1 && tileY - pivotY == -1)
            {
                tile.MoveHorizontal(-1, board);
                tile.MoveHorizontal(-1, board);
            }
            //LowerLeft -> UpperLeft
            if (tileX - pivotX == -1 && tileY - pivotY == -1)
            {
                tile.MoveUp(board);
                tile.MoveUp(board);
            }
            //UpperLeft -> UpperRight 
            if (tileX - pivotX == -1 && tileY - pivotY == 1)
            {
                tile.MoveHorizontal(1, board);
                tile.MoveHorizontal(1, board);
            }
        }

        List<Tile_Complete> temp = bottomTiles;
        bottomTiles = rightTiles;
        rightTiles = upperTiles;
        upperTiles = leftTiles;
        leftTiles = temp;

        // Check to make sure that all locations in the grid for the tiles are occupied
        // appropriately
        foreach (Tile_Complete tile in blockTiles) {
            Vector3 position = tile.GetPosition();
            int tileX = (int)position.x;
            int tileY = (int)position.y;

            if (tileY >= 0 && tileY <= 17)
            {
                board[tileX, tileY] = true;
            }
        }
    }
}
