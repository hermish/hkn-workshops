﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    private GameObject block;

    public void Start()
    {
        block = this.gameObject;
    }

    public bool CanMoveDown(bool[,] board)
    {
        // TODO: Implement this function
        return false;
    }

    public void MoveDown(bool[,] board) {
        // TODO: Implement this function
        return;
    }

    public void MoveUp(bool[,] board) {
        // TODO: Implement this function
        return;
    }

    public bool CanMoveHorizontal(bool[,] board, int direction) {
        
        // TODO: Implement this function
        return false;
    }

    public void MoveHorizontal(int direction, bool[,] board) {
        // TODO: Implement this function
        return;
    }

    public Vector3 GetPosition() {
        return block.GetComponent<Transform>().position;        
    }
}
