﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class TBlock : MonoBehaviour
{
    public Tile[] blockTiles;

    protected List<Tile> bottomTiles;
    protected List<Tile> upperTiles;
    protected List<Tile> leftTiles;
    protected List<Tile> rightTiles;

    protected Tile pivotTile;

    protected int orientation;

    protected int[,] tileLayout;

    protected virtual void Start()
    {
        blockTiles = GetComponentsInChildren<Tile>();
        bottomTiles = new List<Tile>();
        upperTiles = new List<Tile>();
        leftTiles = new List<Tile>();
        rightTiles = new List<Tile>();
    }

    public void MoveHorizontal(bool[,] board, int direction) {
        // TODO: Implement this function
        return;
    }

    // Return the blocktiles sorted by y index. Left tile (smallest x) in first index
    public List<Tile> sortByX(Tile[] tiles) {
        // TODO: Implement this function
        return null;
    }

    public void MoveDown(bool[,] board) {
        // TODO: Implement this function
        return;
    }

    // Return the blocktiles sorted by y index. Bottom tile (smallest y) in first index
    public List<Tile> sortByY(Tile[] tiles) {
        // TODO: Implement this function
        return null;
    }

    public bool CanMoveHorizontal(bool[,] board, int direction)
    {
        // TODO: Implement this function
        return false;
    }

    public bool CanMoveDown(bool[,] board)
    {
        // TODO: Implement this function
        return false;
    }

    public virtual bool CanRotate(bool[,] board)
    {
        // TODO: Implement this function
        return false;
    }

    public virtual void TryRotation(bool[,] board)
    {
        // TODO: Implement this function
        return;
    }
}
