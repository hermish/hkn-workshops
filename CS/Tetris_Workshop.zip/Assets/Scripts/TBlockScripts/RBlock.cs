﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// The red, square block does not rotate

public class RBlock : TBlock
{
    protected override void Start()
    {
        base.Start();

        // TODO: Initialize the variables
    }

    public override bool CanRotate(bool[,] board)
    {
        return false;
    }

    public override void TryRotation(bool[,] board)
    {
        return;
    }
}
