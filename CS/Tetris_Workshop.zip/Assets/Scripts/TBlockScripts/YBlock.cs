﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YBlock : TBlock
{
    protected override void Start()
    {
        base.Start();

        // TODO: Initialize the variables
    }

    public override void TryRotation(bool[,] board)
    {
        // TODO: Implement this function
        return;
    }
}
