﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TealBlock : TBlock
{
    protected override void Start()
    {
        base.Start();

        // TODO: Initialize the variables
    }

    public override bool CanRotate(bool[,] board) {
        // TODO: Implement this function
        return false;
    }

    public override void TryRotation(bool[,] board)
    {
        // TODO: Implement this function
        return;
    }
}
