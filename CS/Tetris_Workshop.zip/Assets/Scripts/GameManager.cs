﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private int rows = 18;
    private int cols = 10;

    public bool[,] board;
    public GameObject backgroundTile;

    public List<GameObject> TetrisBlocks;

    private bool spawnReady;
    private bool movingAlready;
    private float spawnTimer = 1f;
    // private GameObject currentBlock;

    private TBlock currentBlock;

    private Transform tileHolder;

    void Start()
    {
        board = new bool[cols, rows];
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                board[i, j] = false;
            }
        }
        SetUpBoard();
        spawnReady = true;
        tileHolder = new GameObject("TileHolder").GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        if (spawnReady)
        {
            CheckCompleteRow();
            GameObject tileBlock = SpawnBlock();
            tileBlock.GetComponent<Transform>().parent = tileHolder;
            currentBlock = tileBlock.GetComponent<TBlock>();
            spawnReady = false;
        }
        else
        {
            StartCoroutine(MoveBlockDown());
        }

        // Move block horizontally according to player controls
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            TryMoveHorizontal(currentBlock, 1);
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            TryMoveHorizontal(currentBlock, -1);
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            TryMoveDown(currentBlock);
        }

        // Rotate block according to player controls
        if (Input.GetKeyDown(KeyCode.UpArrow)) {
            TryRotate(currentBlock);
        }

    }

    public void SetUpBoard()
    {
        Transform boardHolder = new GameObject("Board").GetComponent<Transform>();
        for (int i = 0; i < cols; i++)
        {
            for (int j = 0; j < rows; j++)
            {
                GameObject background = Instantiate(backgroundTile, new Vector3(i, j, 0), Quaternion.identity);
                background.GetComponent<Transform>().parent = boardHolder;
            }
        }
    }

    public GameObject SpawnBlock()
    {
        GameObject TetrisBlock = TetrisBlocks[UnityEngine.Random.Range(0, TetrisBlocks.Count)];
        return Instantiate(TetrisBlock, new Vector3(5, 18, 0), Quaternion.identity);
    }

    IEnumerator MoveBlockDown()
    {
        while (!movingAlready)
        {
            movingAlready = true;
            yield return new WaitForSeconds(spawnTimer);
            TryMoveDown(currentBlock);
            movingAlready = false;
            // DebugBoard();
        }
    }

    void CheckCompleteRow()
    {
        // TODO: Implement this function
        return;
    }

    void TryMoveDown(TBlock TetrisBlock)
    {
        // TODO: Implement this function
        return;
    }

    void TryMoveHorizontal(TBlock TetrisBlock, int direction) {
        // TODO: Implement this function
        return;
    }

    void TryRotate(TBlock TetrisBlock) {
        // TODO: Implement this function
        return;
    }

    // Return the blocktiles sorted by y index. Bottom tile (smallest y) in first index
    // Same as function from TBlock except for tileY length
    public List<Tile> sortByY(Tile[] tiles)
    {
        // TODO: Implement this function
        return null;
    }
}
